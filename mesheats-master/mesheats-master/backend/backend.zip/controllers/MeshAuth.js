const MeshUser = require('../models/MeshUser');
const { check, validationResult } = require('express-validator');
const jwt = require('jsonwebtoken');
var { expressjwt: ejwt } = require('express-jwt');

exports.signUp = (req, res) => {

    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        return res.status(200).json({
            param: erros.array()[0].param,
            error: errors.array()[0].msg
        })
    }

    const meshUser = new MeshUser(req.body);

    console.log(meshUser);

    meshUser.save((err, meshuser) => {
        if (err) {
            return res.status(400).json({
                err
            })
        }

        res.json({
            name: meshuser.name,
            email: meshuser.email,
            id: meshuser._id
        })
    })
}

exports.signIn = (req, res) => {
    const { email, password } = req.body;

    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        return res.status(422).json({
            param: errors.array()[0].param,
            error: erros.array()[0].msg
        })
    }

    MeshUser.findOne({ email }, (err, user) => {
        if (err || !user) {
            return res.status(400).json({
                err
            })
        }

        if (!user.authenticate(password)) {
            return res.status(400).json({
                err: "Email-Id and Password Do not match"
            })
        }

        const token = jwt.sign({ _id: user._id }, process.env.SECRET);
        const { _id, name, email, mobile } = user;

        return res.json({
            token, user: { _id, name, email, mobile }
        })
    })
}

exports.signOut = (req, res) => {
    res.clearCookie('token');

    res.json({
        msg: "User Signed Out Successfully"
    })
}