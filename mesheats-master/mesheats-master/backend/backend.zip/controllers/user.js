const User = require('../models/User');
const Address = require('../models/AddressSchema');
const { check, validationResult } = require('express-validator');
const jwt = require('jsonwebtoken');
var { expressjwt: ejwt } = require('express-jwt');
const { signUpMail } = require('../mail/userSignUp');

exports.getUserById = (req, res, next, id) => {
    User.findById(id).exec((err, user) => {
        if (err || !user) {
            return res.status(400).json({
                error: "No User was found"
            })
        }
        req.profile = user;
        next();
    })
}


exports.updateProfile = (req, res) => {

}

exports.addAddress = (req, res) => {

    const address = new Address(req.body);

    console.log(address);

    address.save((err, address) => {
        if (err) {
            return res.status(400).json({
                err
            })
        }

        res.json({
            id: address._id
        })
    })

}

exports.updateAddress = (req, res) => {

}

exports.deleteAddress = (req, res) => {

}