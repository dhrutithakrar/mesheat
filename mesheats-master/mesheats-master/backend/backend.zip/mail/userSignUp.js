var nodemailer = require('nodemailer');

//FIXME: Fix this process.env.MAILD and PASSWORD
const ADMINID = process.env.MAILID || 'mesheats707@gmail.com';
const PASSWORD = process.env.PASSWORD || 'cusguscgohvxqfpc';

const transporter = nodemailer.createTransport({
    service: "gmail",
    port: 465,
    host: "smtp.gmail.com",
    auth: {
        user: ADMINID,
        pass: PASSWORD
    },
    secure: true
})

exports.signUpMail = (email) => {

    const mailData = {
        from: ADMINID,
        to: email,
        subject: 'Welcome to MeshEats Family',
        text: "We're very happy to see you onboard"
    }

    transporter.sendMail(mailData, (err, info) => {
        if (err) {
            return console.log(err);
        }
        console.log("Mail Sent");
    })
}