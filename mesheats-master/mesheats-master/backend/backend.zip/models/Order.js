const mongoose = require('mongoose');
const User = require('./User');
const MeshUser = require('./MeshUser');

const OrderSchema = new mongoose.Schema({
    userid: {
        type: mongoose.ObjectId,
        required: true,
        ref: User
    },
    meshid: {
        type: mongoose.ObjectId,
        required: true,
        ref: MeshUser
    },
    //FIXME: Check this at the payment gateway implementation
    payment: {
        type: String
    },
    quantity: {
        type: Number
    },
    totalbill: {
        type: Number
    },
    // FIXME: Think here once again
    order: {
        type: String
    },
    status: {
        type: String
    },
    suggestion: {
        type: String
    },
    // FIXME: Think over here also 
    feedback: {
        type: String
    }

})

module.exports = mongoose.model('Order', OrderSchema);