var express = require('express');
var router = express.Router();
const { isSignedIn, isAuthenticated } = require('../controllers/auth');
const { addAddress, getUserById } = require('../controllers/user');

// Params
router.param("userId", getUserById);

/* GET users listing. */
router.get('/', function (req, res, next) {
  res.send('respond with a resource');
});

router.post('/addAddress/:userId', isSignedIn, isAuthenticated, addAddress);

module.exports = router;